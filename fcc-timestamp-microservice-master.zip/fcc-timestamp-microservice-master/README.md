# Timestamp Microservice

## Tutorial

This repository corresponds with my [YouTube tutorial](https://www.youtube.com/watch?v=Xk2uJTSrdU4) detailing how to create the timestamp microservice.

## Running Microservice

- `npm install`
- `npm run dev`
- Visit [http://localhost:8000/](http://localhost:8000/)
